<?php 
include_once("../includes.php");


if (isset($_POST["voltar_pagina"]))
?>
<a href="<?php echo $url_funcionario."...funcionario/lista_funcionario.php";?>"



 